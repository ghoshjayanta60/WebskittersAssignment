import firebase from "firebase";
import "firebase/storage";
// import Header from './components/Header';firebase

 var firebaseConfig = {
    apiKey: "AIzaSyAkwZjS5K8dHeeMNSe4-M_6VA7XTfzR2sQ",
    authDomain: "my-react-crud-bb92b.firebaseapp.com",
    databaseURL: "https://my-react-crud-bb92b-default-rtdb.firebaseio.com",
    projectId: "my-react-crud-bb92b",
    storageBucket: "my-react-crud-bb92b.appspot.com",
    messagingSenderId: "756113651948",
    appId: "1:756113651948:web:cfef1b80c8cb91de7ecdc9"
  };
  // Initialize Firebase
  var fireDb = firebase.initializeApp(firebaseConfig);
 /*export mmyfirebase;
 var fireDb=mmyfirebase.database().ref();
  
 export default fireDb;*/
 

  export default fireDb.database().ref();

// export default firebase;
