import fireDb  from "../../firebase";

export const user_details=(userid)=>dispatch=>{
  
            //  console.log('ok');

          fireDb.child('contact').on('value',snapshot=>{
            const contacts= snapshot.val()
           // console.log(contacts)
          let mycontactlist=[]
       //   let flag=0
           for(let id in contacts){
              mycontactlist.push({id,...contacts[id]});
           }

         //  this.setState({ contactlist: mycontactlist });

         mycontactlist.map((element)=>
         {
             if( element.id===userid )
             {
               

                 dispatch({
                    type: 'GET_MY_PROFILE_SUCCESS',
                    payload: element
                  })
              // flag=1
             }
          else{

           // flag=0

          }
           })



          //  if(flag===0){
          //   dispatch({
          //     type: 'GET_MY_PROFILE_SUCCESS',
          //     payload: []
          //   })
          //  }

          })
         




}



