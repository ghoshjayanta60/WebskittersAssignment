import fireDb  from "../../firebase";

export const handleChange=(e)=>dispatch=>{
  
                 dispatch({
                    type: 'On_change_handle',
                    payload: e
                  })            
}

export const Submitted_first_form_validation=()=>dispatch=>{
  
   dispatch({
      type: 'Submitted_first_form_validation',
     
    })            
}

export const Submitted_first_form_validation2=()=>dispatch=>{
  
   dispatch({
      type: 'Submitted_first_form_validation2',
     
    })            
}


export const Second_form_open=()=>dispatch=>{
  
   dispatch({
      type: 'Second_form_open',
     
    })            
}

export const initial_State_blank=()=>dispatch=>{
  
   dispatch({
      type: 'initial_State_blank',
     
    })            
}
export const Back_first_form=()=>dispatch=>{
  
   dispatch({
      type: 'Back_first_form',
     
    })            
}



