
// import {FETCH_login_SUCCESS,} from '../action/loginAction'

const initialState = {
  authenticationid:null,
  items: []
  
 
};

export default function loginReducer(state = initialState, action) {
  switch(action.type) {
   

      case 'FETCH_LOGIN_SUCCESS':
      // All done: set loading "false".
      // Also, replace the items with the ones from the server
      return {
        ...state,
        authenticationid:action.payload.id,
        
        items: action.payload
      };

      case 'FETCH_LOGOUT_SUCCESS':
        // All done: set loading "false".
        // Also, replace the items with the ones from the server
        return {
          ...state,
          authenticationid:null,
          
          items: []
        };

      default:
      // ALWAYS have a default case in a reducer
      return state;
  }
}
