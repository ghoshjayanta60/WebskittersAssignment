import {combineReducers} from 'redux'
import loginReducer from './loginReducer'
import myprofile from './myprofileReducer'
import registerReducer from './registerReducer'

export default combineReducers({

 // orders,
  loginReducer,
  myprofile,
  registerReducer
  
})