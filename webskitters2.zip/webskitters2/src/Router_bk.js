import React from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './components/Home';
import Login from './components/Login';
import Register from './components/Register';
import ResetPassword from './components/Login/ResetPassword';
import ForgotPassword from './components/Login/ForgotPassword';
import Profile from './components/Login/Profile';
import Dashboard from './components/Dashboard';
import Videoplayer from './components/Videoplayer';
import {PrivateRoute} from './PrivateRoute';
import {PrivatevideoRoute} from './PrivatevideoRoute';
import Subscriptions from './components/Subscriptions';
import Subscriptionstatus from './components/Subscriptionstatus';
import {Switch, Route, Redirect } from 'react-router-dom';

class Router extends React.Component {
 

  constructor(props) {
    super(props)
    this.state = {
        subscribtion_validity: ''
    

    };
}



  componentDidMount() {
    this.subscribtion_validity_check()
  }

//  subscription validity check
  subscribtion_validity_check=()=>{

    const axios = require('axios');
    const FormData = require('form-data');
    const user_subscriptiondata = new FormData();

    user_subscriptiondata.append('user_id', localStorage.getItem('user_authenticationid'));


    var user_subscription_config = {
        method: 'post',
        url: 'https://dev.solutionsfinder.co.uk/ottdev/Api/get_subscription_status_validity_chk',
        headers: {
            'Content-Type': 'application/json'
        },
        data: user_subscriptiondata

    };

    axios(user_subscription_config)
        .then(function (response) {
            console.log(response.data);
           
            if (response.data.status === 'valid') {
              localStorage.setItem('valid_status', 'valid');
           // localStorage.setItem('valid_status', '');

                this.setState({
                  subscribtion_validity: 'valid'
               // subscribtion_validity: 'not_valid'
                    
                });

            }
            else{
              localStorage.setItem('valid_status', 'not_valid');
             // localStorage.setItem('valid_status', 'valid');
              this.setState({
                subscribtion_validity: 'not_valid'
            //  subscribtion_validity: 'valid'
                  
              });

            }

        }.bind(this))
        .catch(function (error) {
            console.log(error);
        });


}




  render() {

    const {subscribtion_validity}=this.state
    let subscription_output=''
  
    if(subscribtion_validity==='valid'){

      subscription_output= <PrivateRoute  path="/play/:videoId"  component={Videoplayer} />
    //  subscription_output= <PrivatevideoRoute subscribtion_validity={subscribtion_validity}  path="/play/:videoId"  component={Videoplayer} />
    }
  
  
  

  return (
    <div>
        <Header/>
          <Switch>
            <Route  path="/" exact  component={Home} />
            <Route path="/login"  component={Login} />
            <Route path="/register"  component={Register} />
            <Route path="/forgotpassword"  component={ForgotPassword} />
            <Route path="/plan"  component={Subscriptions} />
            {/* <Route path="/resetpassword"  component={ResetPassword} /> */}

            <Route path="/resetpassword/:userId"  component={ResetPassword} />

            <PrivateRoute path="/profile"  component={Profile} />  
            
            <PrivateRoute path="/subscriptionstatus"  component={Subscriptionstatus} />
            
            <PrivateRoute  path="/dashboard"  component={Dashboard} />,
            {/* <PrivateRoute  path="/play/:videoId"  component={Videoplayer} />, */}
            {subscription_output}
            
            
          </Switch>
        <Footer/>
    </div>
   );
  }
}

export default Router;
