import React from 'react';
import Router from './Router';
import './assets/css/App.scss';
import { connect } from 'react-redux';

class App extends React.Component {
  // constructor(props) {
  //    super(props);
  //    };


  // handleMouseDown = e => {
  //   if (e.button === 0)
  //   {
  //     // Actions to perform when left mouse button is clicked, like update state
  //     e.preventDefault();
  //       return false;
  //   }
  // }

  
  componentDidMount() {
    document.addEventListener('contextmenu', (e) => {
      e.preventDefault();
    });

    // document.addEventListener('keydown', (e) => {
    //   e.preventDefault();
    //   });


  };


  render() {
    
   // localStorage.getItem('user_authenticationid');
   // sessionStorage.setItem()
   

    console.log('local storage set '+localStorage.getItem('user_authenticationid'));
    console.log(this.props.authenticationid);
   // let {authenticationid}=this.props;
      return (
    <div className="App"  >
      
      <Router { ...this.props }  />
    </div>
    );
  }
}

const mapStateToProps = state => ({
  authenticationid: state.loginReducer.authenticationid,
//  userforgotpasstokenid: state.forgotpassword.userforgotpasstokenid
 

});

export default connect(mapStateToProps)(App);

