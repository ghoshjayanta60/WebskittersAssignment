import React from 'react';
import { Route, Redirect } from 'react-router-dom';

export const PrivatevideoRoute = ({ component: Component,subscribtion_validity, ...rest }) => (
    <Route {...rest} render={props => (
        localStorage.getItem('user_authenticationid')
            ?  localStorage.getItem('valid_status') ? <Component {...props} />: ''
            : <Redirect to={{ pathname: '/login', state: { from: props.location } }} />
    )} />
)