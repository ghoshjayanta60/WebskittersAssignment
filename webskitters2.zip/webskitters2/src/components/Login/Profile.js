import React, { Component } from 'react';
// import * as utility from "../../utils/Utility";
import * as strings from "../../utils/Strings";
import { ToastContainer } from 'react-toastify';

import { Container, Row, Col } from 'reactstrap';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
 import { user_details } from '../../redux/action/myprofileAction'

class Profile extends Component {



    constructor(props) {
        super(props)
        this.state = {

        };

        
    }

    componentDidMount() {
        console.log(localStorage.getItem('user_authenticationid'))
       this.props.user_details(localStorage.getItem('user_authenticationid')) 

    }

    
    handleChange = (e) => {
        this.setState({
            [e.target.name] : e.target.value
        })
    }

    render() {
        const {userdetails}=this.props
       

        return (
            <div className="contain-area">
                <Helmet>
                    <title>My Profile | {strings.stringsLocalContainer.SITE_TITLE}</title>
                </Helmet>
                <Container>
                    <Row>
                        <Col md="12" className="profile-new-div">
                            <div role="tabpanel">
                                <Col sm="3">
                                    <div className="user-img">
                                        {/* <img src={require('../../assets/images/big-pic.jpg')} alt="poster"/> */}
                                        <img src="test"

                                            //  onChange={this.onFileChange}
                                            alt="poster" />
                                        <input type="file"
                                            style={{ display: 'none' }}
                                           
                                        ></input>

                                        <div title="edit" style={{ backgroundColor: 'white', width: '20px' }}  >
                                            <i className="fa fa-pencil-alt" aria-hidden="true"></i>

                                        </div>
                                        {/* <img src={this.state.profile_img} alt="my phonto"></img>
                                        <input type="button" onClick={()=>this.onFileupload()} value="upload"></input> */}
                                    </div>
                                <div className="user-name">Hello {userdetails.firstname}</div>
                                <div className="user-name"> {userdetails.phone}</div>
                                <div className="user-name"> {userdetails.email}</div>
                                    <div className="user-sicial">
                                        <i className="fa fa-facebook" aria-hidden="true"></i>
                                        <i className="fa fa-twitter" aria-hidden="true"></i>
                                        <i className="fa fa-youtube-play" aria-hidden="true"></i>
                                        <i className="fa fa-pinterest" aria-hidden="true"></i>
                                    </div>
                                    <ul className="nav nav-pills brand-pills nav-stacked" role="tablist">
                                        <li role="presentation" className="brand-nav active">
                                            <a href="#tab1" aria-controls="tab1" role="tab" data-toggle="tab"> <i className="fa fa-user" aria-hidden="true"></i> Basic Details</a>
                                        </li>
                                        
                                        <li role="presentation" className="brand-nav">
                                            <a href="#tab2" aria-controls="tab2" role="tab" data-toggle="tab"> <i className="fa fa-cog" aria-hidden="true"></i> Settings</a>
                                        </li>
                                    </ul>
                                </Col>
                                <Col sm="9" className="tab-desc-area">
                                    <div className="tab-content">
                                      
                                        <div role="tabpanel" className="tab-pane active" id="tab1">
                                            <div className="panel-heading">
                                                <h3 className="panel-title">Profile</h3>
                                            </div>
                                            <form method="post">
                                                <fieldset>

                                               



                                                    <div className="input-name" >
                                                        <input type="email"  name="username" placeholder="Name" />
                                                        <span className="underline-animation"></span>
                                                    </div>
                                                    <br />
                                                    <div className="input-name" >
                                                        <input type="email"  name="email" placeholder="Email"  />
                                                        <span className="underline-animation"></span>
                                                    </div>
                                                    <br />
                                                    
                                                    <input  className="btn btn-lg btn-success btn-block" type="submit" value="Update" />
                                                </fieldset>
                                            </form>
                                            <div className="line-form"><ToastContainer /></div>
                                            {/* <center>
                                    <h4>Or</h4>
                                </center> */}
                                        </div>

                                        <div role="tabpanel" className="tab-pane" id="tab2">
                                            <div className="panel-heading">
                                                <h3 className="panel-title">Change Password</h3>
                                            </div>
                                            <form method="post">
                                                <fieldset>

                                                    <div className="input-name" >
                                                        <input type="Email"  name="username" placeholder="Name" />
                                                        <span className="underline-animation"></span>
                                                    </div>
                                                    <br />
                                                    <div className="input-name" >
                                                        <input type="Email"  name="email" placeholder="Email" />
                                                        <span className="underline-animation"></span>
                                                    </div>
                                                    <br />
                                                    
                                                    <input  className="btn btn-lg btn-success btn-block" type="submit" value="Update" />
                                                </fieldset>
                                            </form>
                                            <div className="line-form"><ToastContainer /></div>
                                            {/* <center>
                                    <h4>Or</h4>
                                </center> */}
                                        </div>
                                       
                                       
                                       
                                   



                                    </div>
                                </Col>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </div>
        );
    }
}


const mapStateToProps = state => ({
    userdetails: state.myprofile.userdetails
})

const mapDispatchToProps={
    user_details
   }


export default connect(mapStateToProps,mapDispatchToProps)(Profile);
