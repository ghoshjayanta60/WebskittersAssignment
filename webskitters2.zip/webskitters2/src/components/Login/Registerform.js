import React, { Component }  from 'react';
import { Link } from 'react-router-dom';
import {Helmet} from "react-helmet";
import * as utility from "../../utils/Utility";
import * as strings from "../../utils/Strings";
import { handleChange ,    
    Submitted_first_form_validation,
    Submitted_first_form_validation2,
    Second_form_open,
    initial_State_blank,
    Back_first_form

} from '../../redux/action/registerAction'
import { connect } from 'react-redux';


import { ToastContainer } from 'react-toastify';

import fireDb  from "../../firebase";

class Registerform extends Component{
    constructor(props) {
        super(props)
        this.state = {
           
        };
    }
   
  
   

    onSubmit = (e) => {
        e.preventDefault();
       // this.setState({ submitted: true });
       this.props.Submitted_first_form_validation()

        if(!this.props.registerReducer.firstname && !this.props.registerReducer.lastname && !this.props.registerReducer.email && !this.props.registerReducer.password && !this.props.registerReducer.phone  && !this.props.registerReducer.conpassword){
            utility.showError("Please fill up all the fields");
            return false;
        }

        if(!this.props.registerReducer.firstname){
            utility.showError("Please Enter First name");
            return false;
        }

        if(!this.props.registerReducer.lastname){
            utility.showError("Please Enter Last name");
            return false;
        }


        if(utility.validateEmail(this.props.registerReducer.email)){
            utility.showError("Please Enter valid Email");
            return false;
        }
        if(!utility.validatePhone(this.props.registerReducer.phone)){
            utility.showError("Please Enter valid Phone No.");
            return false;
        }
     

        if(!this.props.registerReducer.password   || !this.props.registerReducer.conpassword){
            utility.showError("Please fill password");
            return false;
        }
        if(this.props.registerReducer.password !== this.props.registerReducer.conpassword){
            utility.showError("Password dose not match");
            return false;
        }
        
        // fireDb.child('contact').push({
        //     firstname:this.props.registerReducer.firstname,
        //     lastname:this.props.registerReducer.lastname,
        //     email:this.props.registerReducer.email,
        //     phone:this.props.registerReducer.phone,
        //     city:this.props.registerReducer.city,
        //     password:this.props.registerReducer.password



        // },err=>{
        //     if(err){
        //         console.log(err)
        //     }

        //     else {
        //         utility.showSuccess('Successfully Register.');

        //         this.props.Second_form_open()
        //     } 
        // })

        this.props.Second_form_open()


    }


    onSubmit_second_form = (e) => {
        e.preventDefault();
       // this.setState({ submitted: true });
       this.props.Submitted_first_form_validation2()

        if(!this.props.registerReducer.pincode && !this.props.registerReducer.city){
            utility.showError("Please fill up all the fields");
            return false;
        }

        if(!this.props.registerReducer.pincode){
            utility.showError("Please Enter Pincode");
            return false;
        }
       

        if(!this.props.registerReducer.city){
            utility.showError("Please Enter city");
            return false;
        }


       
        
        fireDb.child('contact').push({
            firstname:this.props.registerReducer.firstname,
            lastname:this.props.registerReducer.lastname,
            email:this.props.registerReducer.email,
            phone:this.props.registerReducer.phone,
            pincode:this.props.registerReducer.pincode,
            city:this.props.registerReducer.city,
            password:this.props.registerReducer.password



        },err=>{
            if(err){
                console.log(err)
            }

            else {
                utility.showSuccess('Successfully Register.');

                this.props.initial_State_blank()
            } 
        })

        


    }







    render() {
    const { firstname, lastname, email, phone, city, password,conpassword,pincode, submitted,submitted2,show_form2 } = this.props.registerReducer;



    
    // console.log(comment_list)
     let show_form2_output = ''
     if (show_form2) {
        show_form2_output =
         (
           <div>
             <fieldset>
                                                                
                                     
                                    <div className={'input-name' + (submitted2 && !pincode ? ' has-error' : '')}>
                                        <input placeholder="pincode" name="pincode" type="email" value={this.props.registerReducer.pincode} onChange={e => this.props.handleChange(e)} />
                                        <span className="underline-animation"></span>
                                    </div>

                                    <div className={'input-name' + (submitted2 && !city ? ' has-error' : '')}>
                                        <input placeholder="city" name="city" type="email" value={this.props.registerReducer.city} onChange={e => this.props.handleChange(e)} />
                                        <span className="underline-animation"></span>
                                    </div>

                                   
                                    <input onClick={() => this.props.Back_first_form()} className="btn btn-lg btn-success btn-block" type="button" value="Back" />
                                         
                                        <input onClick={(e) => this.onSubmit_second_form(e)} className="btn btn-lg btn-success btn-block" type="submit" value="Sign Up" />
                                    </fieldset>
                 
         </div>
         )
 
     }
     else {
        show_form2_output =
       (
        <div>
        <fieldset>
                               <div className={'input-name' + (submitted && !firstname ? ' has-error' : '')}>
                                   <input placeholder="First Name" name="firstname" type="email" value={this.props.registerReducer.firstname} onChange={e => this.props.handleChange(e)} />
                                   <span className="underline-animation"></span>
                               </div>
                               <div className={'input-name' + (submitted && !lastname ? ' has-error' : '')}>
                                   <input placeholder="Last Name" name="lastname" type="email" value={this.props.registerReducer.lastname} onChange={e => this.props.handleChange(e)} />
                                   <span className="underline-animation"></span>
                               </div>
                               <div className={'input-name' + (submitted && !email ? ' has-error' : '')}>
                                   <input placeholder="Email" name="email" type="email" value={this.props.registerReducer.email} onChange={e => this.props.handleChange(e)} />
                                   <span className="underline-animation"></span>
                               </div>
                               <div className={'input-name' + (submitted && !phone ? ' has-error' : '')}>
                                   <input placeholder="Phone" name="phone" type="tel" value={this.props.registerReducer.phone} onChange={e => this.props.handleChange(e)} />
                                   <span className="underline-animation"></span>
                               </div>                                        
                             
                               <div className={'input-name' + (submitted && !password ? ' has-error' : '')}>
                                   <input placeholder="Password" name="password" type="password" value={this.props.registerReducer.password} onChange={e => this.props.handleChange(e)} />
                                   <span className="underline-animation"></span>
                               </div>

                               <div className={'input-name' + (submitted && !conpassword ? ' has-error' : '')}>
                                   <input placeholder="Confirm Password" name="conpassword" type="password" value={this.props.registerReducer.conpassword} onChange={e => this.props.handleChange(e)} />
                                   <span className="underline-animation"></span>
                               </div>


                                   <input onClick={(e) => this.onSubmit(e)} className="btn btn-lg btn-success btn-block" type="submit" value="Save" />
                               </fieldset>
            
    </div>
       )
     }








    return (        
        <div className="contain-area">
            <Helmet>
                <title>Register | {strings.stringsLocalContainer.SITE_TITLE}</title>
            </Helmet>
	        <div className="container">                
		        <div className="row">
                    <div className="col-md-6">
                        <div className="login-area2">
                            <Link to="/">
                                <img src={require('../../assets/images/big-pic.jpg')} alt="poster" className="formImg" />
                            </Link>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="panel panel-default login-area2">                            
                            <div className="panel-body">
                                <div className="panel-heading">
                                    <h3 className="panel-title">Registration</h3>
                                </div>
                                <form id="registration" method="post">
                                    {
                                        show_form2_output
                                    }
                                </form>
                            <div className="line-form"><ToastContainer /></div>
                                <center>
                                    <h4>OR</h4>
                                </center>
                            <div className="login-with">Login With</div>
                                <div className="social-logo">
                                    <Link to="/">
                                        <img src={require('../../assets/images/g-logo.png')} alt="google" />
                                    </Link>
                                    <Link to="/">
                                        <img src={require('../../assets/images/f-logo.png')} alt="facebook" />
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
  }
}

const mapStateToProps = state => ({
    registerReducer: state.registerReducer
})

const mapDispatchToProps={
    handleChange,
    Submitted_first_form_validation,
    Submitted_first_form_validation2,
    Second_form_open,
    initial_State_blank,
    Back_first_form
   }


export default connect(mapStateToProps,mapDispatchToProps)(Registerform);