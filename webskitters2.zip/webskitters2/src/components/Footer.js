import React, { Component }  from 'react';
import Footertop from './Footertop';

export default class Footer extends Component{
  render() {
    return (
        <Footertop />
    );
  }
}
